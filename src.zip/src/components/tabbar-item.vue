<template>
    <a class="m-tabbar-item" :class="{'is-active':isActive}" @click="$parent.$emit('input',id)">
        <span class="m-tabbar-item-icon" v-show="!isActive"><slot name="icon-normal"></slot></span>
        <span class="m-tabbar-item-icon" v-show="isActive"><slot name="icon-active"></slot></span>
        <span class="m-tabbar-item-text"><slot></slot></span>
    </a>
</template>
<script>
    export default{
      props: ['id'],
      computed: {
        isActive () {
            if (this.$parent.value === this.id) {
              return true
            }
         }
      }
    }
</script>
<style lang="less">
.m-tabbar-item{
    flex: 1;
    text-align: center;
    border-bottom: 1px solid gray;
    padding: 4px;
    .m-tabbar-item-icon{
        display: block;
        img{
            width: 75px;
            height: 75px;
        }
    }
    .m-tabbar-item-text{
        display: block;
        font-size: 18px;
        color:black;
    }
    &.is-active{
        .m-tabbar-item-text{
            color: #42bd56;
        }
    }
}
</style>
