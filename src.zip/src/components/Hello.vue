<template>
  <ul>
  <li v-for="(item, index) in items" v-bind:class="{ bgColor: index==selectItem }" @click="onclick(index)">
 
     <div> 
       <img src="../assets/1-1.png"  style="position:absolute;">
     </div>
     <div>
      {{ index }} - {{ item.message }}
     </div>
    
  </li>
  </ul>

</template>

<script>
// import a from '../assets/1.png'
import b from '../assets/1-1.png'
// import c from '../assets/2.png'
// import d from '../assets/2-1.png'
// import e from '../assets/3.png'
// import f from '../assets/3-1.png'

export default {
  name: 'Hello',
  data () {
    return {
      selectItem: 0,
      items: [
        { message: 'Foo', imgUrl: b }
        // { message: 'Bar', imgUrl: c },
        // { message: 'Foo', imgUrl: e }
      ]
    }
  },
  methods: {
    onclick: function (index) {
      this.selectItem = index
    }
  },
  created () {
  }
}
</script>

<style lang="css">
   	.bgColor {
			color: blue;
		}
</style>

