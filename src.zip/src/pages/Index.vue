<template>
  <div>
    <m-tabbar v-model="select">
      <m-tabbar-item v-for="(item, index) in items" :id="index" :key="index">
        <img :src="item.iconNormarl" alt="" slot="icon-normal">
        <img :src="item.iconActive" alt="" slot="icon-active">
         {{item.message}}
      </m-tabbar-item>
    </m-tabbar>
  </div>
</template>

<script>
  import mTabbar from '../components/tabbar'
  import mTabbarItem from '../components/tabbar-item'
  import configItem from '../config/config.js'

  export default {
    name: 'index',
    components: {
      mTabbar,
      mTabbarItem
    },
    data() {
      return {
        select: 0,
        items: configItem.items
      }
    }
  }
</script>