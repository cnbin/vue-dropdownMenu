import a from '../assets/images/ic_tab_home_normal.png'
import b from '../assets/images/ic_tab_subject_normal.png'
import c from '../assets/images/ic_tab_status_normal.png'
import d from '../assets/images/ic_tab_group_normal.png'
import e from '../assets/images/ic_tab_profile_normal.png'

import aa from '../assets/images/ic_tab_home_active.png'
import bb from '../assets/images/ic_tab_subject_active.png'
import cc from '../assets/images/ic_tab_status_active.png'
import dd from '../assets/images/ic_tab_group_active.png'
import ee from '../assets/images/ic_tab_profile_active.png'

export default {
    items: [
            {message: 'tab1', iconNormarl:a, iconActive:aa},
            {message: 'tab2', iconNormarl:b, iconActive:bb},
            {message: 'tab3', iconNormarl:c, iconActive:cc},
            {message: 'tab4', iconNormarl:d, iconActive:dd},
            {message: 'tab5', iconNormarl:e, iconActive:ee},
            {message: 'tab6', iconNormarl:a, iconActive:aa},
            {message: 'tab7', iconNormarl:b, iconActive:bb},
            {message: 'tab8', iconNormarl:c, iconActive:cc},
            {message: 'tab9', iconNormarl:d, iconActive:dd},
            {message: 'tab10', iconNormarl:e, iconActive:ee}
          ]
}