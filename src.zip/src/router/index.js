import Vue from 'vue'
import Router from 'vue-router'
import Hello from '@/components/Hello'
import Mint from 'mint-ui'
import 'mint-ui/lib/style.css'
import Index from '../pages/Index'

Vue.use(Mint)
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Index',
      component: Index
    }
  ]
})
